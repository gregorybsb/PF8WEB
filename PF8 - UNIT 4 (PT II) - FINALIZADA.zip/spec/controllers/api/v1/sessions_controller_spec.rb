require 'rails_helper'

RSpec.describe Api::V1::SessionsController, type: :controller do

end
