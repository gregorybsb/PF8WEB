class ApplicationController < ActionController::API
    include Authenticable
end
